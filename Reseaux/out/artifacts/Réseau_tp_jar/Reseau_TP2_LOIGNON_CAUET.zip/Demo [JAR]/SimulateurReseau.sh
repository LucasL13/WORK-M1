#!/bin/bash

cd sources
java -Dsun.java2d.opengl=true -jar Réseau_tp.jar
